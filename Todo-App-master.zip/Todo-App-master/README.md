# Todo-App
 A Todo App has been created using HTML,CSS,Jquery,Bootstrap where the user can enter the text and can add it to main Html Page.The user can also delete the added portion of data on clicking on bin image .Also the user can choose the color of the background to be given to the data added.
### Todo-App Url
[Click ME!...](https://manik410.github.io/Todo-App/index)
